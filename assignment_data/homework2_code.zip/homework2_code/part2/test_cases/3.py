
t = input()
c = input()

while c:
    if t:
        t = c
        y = t
    if y:
        x = c
