
t = input()
c = input()

while c:
    if t:
        t = c
        y = t
    if c:
        x = c
    w = x

y = w

