
t = input()
c = input()
x = input()
w = input()

while c:
    y = input()
    if x:
        if w:
            x  = w
        else:
            z=   y
    if t:
        w = y

