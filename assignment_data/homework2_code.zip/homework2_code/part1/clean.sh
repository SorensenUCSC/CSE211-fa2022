
rm opt.cpp a.out *~
