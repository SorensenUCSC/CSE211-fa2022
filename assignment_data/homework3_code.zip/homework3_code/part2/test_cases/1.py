for i in range(0,10):
    a[i] = a[11]
