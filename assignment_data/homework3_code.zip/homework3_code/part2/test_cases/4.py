for i in range(7,10):
    for j in range(5,500):
        for k in range(0,10):
            a[i*j*k] = a[k]
