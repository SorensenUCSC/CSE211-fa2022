for i in range(0,11):
    for j in range(0,10):
        a[i*j] = a[57]
