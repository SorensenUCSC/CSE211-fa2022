#include <assert.h>

void check_values(double *ref, double *actual, int size) {
} 
