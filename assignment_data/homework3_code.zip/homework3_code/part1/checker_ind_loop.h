#include <assert.h>

void check_values(float *ref, float *actual, int size) {
} 
